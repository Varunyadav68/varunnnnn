async function fetchData() {
    try {
        const response = await fetch('https://jsonplaceholder.typicode.com/posts');

        // Check response status
        if (!response.ok) {
            throw new Error(`HTTP error! Status: ${response.status}`);
        }

        // Convert response into JSON
        const data = await response.json();

        // Display data
        console.log(data);

    } catch (error) {
        console.error('Fetch error:', error.message);
    }
}

// Call the function
fetchData();